/*
 *  Copyright (C) 2021 Texas Instruments Incorporated
 *
 *  Redistribution and use in source and binary forms, with or without
 *  modification, are permitted provided that the following conditions
 *  are met:
 *
 *    Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 *    Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the
 *    distribution.
 *
 *    Neither the name of Texas Instruments Incorporated nor the names of
 *    its contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 *  THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 *  "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 *  LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
 *  A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT
 *  OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
 *  SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
 *  LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
 *  DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
 *  THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 *  (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
 *  OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */
#include <stdio.h>
#include <string.h>
#include <inttypes.h>
#include <kernel/dpl/ClockP.h>
#include <kernel/dpl/DebugP.h>
#include <drivers/ipc_notify.h>
#include <drivers/ipc_rpmsg.h>
#include <math.h>
#include <FreeRTOS.h>
#include <task.h>
#include <drivers/gpio.h>
#include <kernel/dpl/AddrTranslateP.h>
#include <tiescutils.h>
#include <tiesceoefoe.h>
#include <tiescsoc.h>
#include <applInterface.h>
#include <ecatslv.h>
#include "ti_drivers_open_close.h"
#include "ti_board_open_close.h"

/* This example shows message exchange between multiple cores.
 *
 * One of the core is designated as the 'main' core
 * and other cores are designated as `remote` cores.
 *
 * The main core initiates IPC with remote core's by sending it a message.
 * The remote cores echo the same message to the main core.
 *
 * The main core repeats this for gMsgEchoCount iterations.
 *
 * In each iteration of message exchange, the message value is incremented.
 *
 * When iteration count reaches gMsgEchoCount, the example is completed.
 *
 */

uint8_t ipc_execute_line(char *line);

extern uint32_t gHS_val;


/* maximum size that message can have in this example */
#define MAX_MSG_SIZE        (128u)

char msgBuf[128];

/* Receive gcode data from EtherCAT Master, update msgBuf */
int update_gcode_cmdbuf(uint8_t TmpCount, uint8_t TmpCmd, uint16_t TmpMotorData)
{
    static int idx = 0;

    if(idx==0)
        memset(msgBuf, 0, 128-1);

    msgBuf[idx] = (char)TmpCount;
    msgBuf[idx+1] = (char)TmpCmd;
    msgBuf[idx+2] = (char)(TmpMotorData>>8);
    msgBuf[idx+3] = (char)(TmpMotorData & 0xff);


    if((TmpCount==0) || (TmpCmd==0) || (msgBuf[idx+2]==0) || (msgBuf[idx+3]==0))
    {
#ifdef MYDEBUG
        DebugP_log("msgBug %s\r\n", msgBuf);
#endif
        idx = 0;
        return 1;
    }
    else
        idx = idx + 4;

    return 0;
}

/* Receive and print gcode data from EtherCAT Master */
int print_GCode(uint8_t TmpCount, uint8_t TmpCmd, uint16_t TmpMotorData)
{
    DebugP_log("print_GCode: %c %c %c %c\r\n", TmpCount, TmpCmd, (TmpMotorData>>8), (TmpMotorData & 0xff));
    if(TmpCount==0)
        return 1;
    if(TmpCmd==0)
        return 1;
    if((TmpMotorData >> 8)==0)
        return 1;
    if((TmpMotorData & 0xff)==0)
        return 1;
    return 0;
}

/* Task to keep monitoring gcode data buffer and transfer the command to other cores */
int motor_demo_main(void)
{
    DebugP_log("Motor Demo Started\r\n");
    memset(msgBuf, 0, MAX_MSG_SIZE-1);
    uint32_t hs_val;

    bMotorApplication = TRUE;
    bGCodeCommandRunning = FALSE;
    do
    {
        hs_val = tiesc_readHomeSwitch();
        if((hs_val & 0x08) && (hs_val & 0x10) && (hs_val & 0x20))
            gHS_val = 1;
        else
            gHS_val = 0;

        if(bGCodeCommandRunning==TRUE)
        {
            // Just received gcode command line
            bGCodeCommandRunning = FALSE;
            // Send gcode command to other cores
            ipc_execute_line(msgBuf);
        }
        else
            vTaskDelay(5);
    }
    while(bMotorApplication == TRUE);
    /* This loop will never exit */
    return 0;
}

