/*
 *  Copyright (C) 2021 Texas Instruments Incorporated
 *
 *  Redistribution and use in source and binary forms, with or without
 *  modification, are permitted provided that the following conditions
 *  are met:
 *
 *    Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 *    Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the
 *    distribution.
 *
 *    Neither the name of Texas Instruments Incorporated nor the names of
 *    its contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 *  THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 *  "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 *  LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
 *  A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT
 *  OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
 *  SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
 *  LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
 *  DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
 *  THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 *  (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
 *  OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

#include <drivers/gpio.h>
#include <kernel/dpl/AddrTranslateP.h>
#include <kernel/dpl/DebugP.h>
#include <kernel/dpl/ClockP.h>
#include "ti_drivers_config.h"
#include "ti_drivers_open_close.h"
#include "ti_board_open_close.h"

/*
 * This example configures a GPIO pin connected to an LED on the EVM in
 * output mode.
 * The application toggles the LED on/off for 10 seconds and exits.
 */

void gpio_led_blink_main(void *args)
{
    uint32_t    loopcnt = 5, delaySec = 1;
    uint32_t    gpioBaseAddr;

    /* Open drivers to open the UART driver for console */
    Drivers_open();
    Board_driversOpen();
#if 0
    gpioBaseAddr = (uint32_t) AddrTranslateP_getLocalAddr(EN_X_BASE_ADDR);
    GPIO_setDirMode(gpioBaseAddr, EN_X_PIN, EN_X_DIR);
    ClockP_sleep(1);
    GPIO_pinWriteLow(gpioBaseAddr, EN_X_PIN);

    gpioBaseAddr = (uint32_t) AddrTranslateP_getLocalAddr(DIR_X_BASE_ADDR);
    GPIO_setDirMode(gpioBaseAddr, DIR_X_PIN, DIR_X_DIR);
    ClockP_sleep(1);
    GPIO_pinWriteLow(gpioBaseAddr, DIR_X_PIN);

    gpioBaseAddr = (uint32_t) AddrTranslateP_getLocalAddr(STEP_X_BASE_ADDR);
    GPIO_setDirMode(gpioBaseAddr, STEP_X_PIN, STEP_X_DIR);

    gpioBaseAddr = (uint32_t) AddrTranslateP_getLocalAddr(EN_Y_BASE_ADDR);
    GPIO_setDirMode(gpioBaseAddr, EN_Y_PIN, EN_Y_DIR);
    ClockP_sleep(1);
    GPIO_pinWriteLow(gpioBaseAddr, EN_Y_PIN);

    gpioBaseAddr = (uint32_t) AddrTranslateP_getLocalAddr(DIR_Y_BASE_ADDR);
    GPIO_setDirMode(gpioBaseAddr, DIR_Y_PIN, DIR_Y_DIR);
    ClockP_sleep(1);
    GPIO_pinWriteLow(gpioBaseAddr, DIR_Y_PIN);

    gpioBaseAddr = (uint32_t) AddrTranslateP_getLocalAddr(STEP_Y_BASE_ADDR);
    GPIO_setDirMode(gpioBaseAddr, STEP_Y_PIN, STEP_Y_DIR);

    gpioBaseAddr = (uint32_t) AddrTranslateP_getLocalAddr(EN_Z_BASE_ADDR);
    GPIO_setDirMode(gpioBaseAddr, EN_Z_PIN, EN_Z_DIR);
    ClockP_sleep(1);
    GPIO_pinWriteLow(gpioBaseAddr, EN_Z_PIN);

    gpioBaseAddr = (uint32_t) AddrTranslateP_getLocalAddr(DIR_Z_BASE_ADDR);
    GPIO_setDirMode(gpioBaseAddr, DIR_Z_PIN, DIR_Z_DIR);
    ClockP_sleep(1);
    GPIO_pinWriteLow(gpioBaseAddr, DIR_Z_PIN);

    gpioBaseAddr = (uint32_t) AddrTranslateP_getLocalAddr(STEP_Z_BASE_ADDR);
    GPIO_setDirMode(gpioBaseAddr, STEP_Z_PIN, STEP_Z_DIR);

    while(1)
    {
        gpioBaseAddr = (uint32_t) AddrTranslateP_getLocalAddr(STEP_X_BASE_ADDR);
        GPIO_pinWriteHigh(gpioBaseAddr, STEP_X_PIN);
        gpioBaseAddr = (uint32_t) AddrTranslateP_getLocalAddr(STEP_Y_BASE_ADDR);
        GPIO_pinWriteHigh(gpioBaseAddr, STEP_Y_PIN);
        gpioBaseAddr = (uint32_t) AddrTranslateP_getLocalAddr(STEP_Z_BASE_ADDR);
        GPIO_pinWriteHigh(gpioBaseAddr, STEP_Z_PIN);
        ClockP_usleep(1000);
        gpioBaseAddr = (uint32_t) AddrTranslateP_getLocalAddr(STEP_X_BASE_ADDR);
        GPIO_pinWriteLow(gpioBaseAddr, STEP_X_PIN);
        gpioBaseAddr = (uint32_t) AddrTranslateP_getLocalAddr(STEP_Y_BASE_ADDR);
        GPIO_pinWriteLow(gpioBaseAddr, STEP_Y_PIN);
        gpioBaseAddr = (uint32_t) AddrTranslateP_getLocalAddr(STEP_Z_BASE_ADDR);
        GPIO_pinWriteLow(gpioBaseAddr, STEP_Z_PIN);
        ClockP_usleep(1000);
    }
#endif
#if 1

    DebugP_log("GPIO toggle for %d seconds ...\r\n", (loopcnt * delaySec * 2));
#if 0
    /* Get address after translation translate */
    gpioBaseAddr = (uint32_t) AddrTranslateP_getLocalAddr(EN_X_BASE_ADDR);
    GPIO_setDirMode(gpioBaseAddr, EN_X_PIN, EN_X_DIR);
    gpioBaseAddr = (uint32_t) AddrTranslateP_getLocalAddr(STEP_X_BASE_ADDR);
    GPIO_setDirMode(gpioBaseAddr, STEP_X_PIN, STEP_X_DIR);
    gpioBaseAddr = (uint32_t) AddrTranslateP_getLocalAddr(DIR_X_BASE_ADDR);
    GPIO_setDirMode(gpioBaseAddr, DIR_X_PIN, DIR_X_DIR);
    gpioBaseAddr = (uint32_t) AddrTranslateP_getLocalAddr(FAULT_X_BASE_ADDR);
    GPIO_setDirMode(gpioBaseAddr, FAULT_X_PIN, FAULT_X_DIR);
    gpioBaseAddr = (uint32_t) AddrTranslateP_getLocalAddr(EN_Y_BASE_ADDR);
    GPIO_setDirMode(gpioBaseAddr, EN_Y_PIN, EN_Y_DIR);
    gpioBaseAddr = (uint32_t) AddrTranslateP_getLocalAddr(STEP_Y_BASE_ADDR);
    GPIO_setDirMode(gpioBaseAddr, STEP_Y_PIN, STEP_Y_DIR);
    gpioBaseAddr = (uint32_t) AddrTranslateP_getLocalAddr(DIR_Y_BASE_ADDR);
    GPIO_setDirMode(gpioBaseAddr, DIR_Y_PIN, DIR_Y_DIR);
    gpioBaseAddr = (uint32_t) AddrTranslateP_getLocalAddr(FAULT_Y_BASE_ADDR);
    GPIO_setDirMode(gpioBaseAddr, FAULT_Y_PIN, FAULT_Y_DIR);
    gpioBaseAddr = (uint32_t) AddrTranslateP_getLocalAddr(EN_Z_BASE_ADDR);
    GPIO_setDirMode(gpioBaseAddr, EN_Z_PIN, EN_Z_DIR);
    gpioBaseAddr = (uint32_t) AddrTranslateP_getLocalAddr(STEP_Z_BASE_ADDR);
    GPIO_setDirMode(gpioBaseAddr, STEP_Z_PIN, STEP_Z_DIR);
    gpioBaseAddr = (uint32_t) AddrTranslateP_getLocalAddr(DIR_Z_BASE_ADDR);
    GPIO_setDirMode(gpioBaseAddr, DIR_Z_PIN, DIR_Z_DIR);
    gpioBaseAddr = (uint32_t) AddrTranslateP_getLocalAddr(FAULT_Z_BASE_ADDR);
    GPIO_setDirMode(gpioBaseAddr, FAULT_Z_PIN, FAULT_Z_DIR);
    gpioBaseAddr = (uint32_t) AddrTranslateP_getLocalAddr(ALERT_X_BASE_ADDR);
    GPIO_setDirMode(gpioBaseAddr, ALERT_X_PIN, ALERT_X_DIR);
    gpioBaseAddr = (uint32_t) AddrTranslateP_getLocalAddr(ALERT_Y_BASE_ADDR);
    GPIO_setDirMode(gpioBaseAddr, ALERT_Y_PIN, ALERT_Y_DIR);
#endif

    while(1)
    {
#if 0
        gpioBaseAddr = (uint32_t) AddrTranslateP_getLocalAddr(EN_X_BASE_ADDR);
        GPIO_pinWriteHigh(gpioBaseAddr, EN_X_PIN);
        gpioBaseAddr = (uint32_t) AddrTranslateP_getLocalAddr(STEP_X_BASE_ADDR);
        GPIO_pinWriteHigh(gpioBaseAddr, STEP_X_PIN);
        gpioBaseAddr = (uint32_t) AddrTranslateP_getLocalAddr(DIR_X_BASE_ADDR);
        GPIO_pinWriteHigh(gpioBaseAddr, DIR_X_PIN);
        gpioBaseAddr = (uint32_t) AddrTranslateP_getLocalAddr(EN_Y_BASE_ADDR);
        GPIO_pinWriteHigh(gpioBaseAddr, EN_Y_PIN);
        gpioBaseAddr = (uint32_t) AddrTranslateP_getLocalAddr(STEP_Y_BASE_ADDR);
        GPIO_pinWriteHigh(gpioBaseAddr, STEP_Y_PIN);
        gpioBaseAddr = (uint32_t) AddrTranslateP_getLocalAddr(DIR_Y_BASE_ADDR);
        GPIO_pinWriteHigh(gpioBaseAddr, DIR_Y_PIN);
        gpioBaseAddr = (uint32_t) AddrTranslateP_getLocalAddr(EN_Z_BASE_ADDR);
        GPIO_pinWriteHigh(gpioBaseAddr, EN_Z_PIN);
        gpioBaseAddr = (uint32_t) AddrTranslateP_getLocalAddr(STEP_Z_BASE_ADDR);
        GPIO_pinWriteHigh(gpioBaseAddr, STEP_Z_PIN);
        gpioBaseAddr = (uint32_t) AddrTranslateP_getLocalAddr(DIR_Z_BASE_ADDR);
        GPIO_pinWriteHigh(gpioBaseAddr, DIR_Z_PIN);

        ClockP_sleep(delaySec);

        gpioBaseAddr = (uint32_t) AddrTranslateP_getLocalAddr(EN_X_BASE_ADDR);
        GPIO_pinWriteLow(gpioBaseAddr, EN_X_PIN);
        gpioBaseAddr = (uint32_t) AddrTranslateP_getLocalAddr(STEP_X_BASE_ADDR);
        GPIO_pinWriteLow(gpioBaseAddr, STEP_X_PIN);
        gpioBaseAddr = (uint32_t) AddrTranslateP_getLocalAddr(DIR_X_BASE_ADDR);
        GPIO_pinWriteLow(gpioBaseAddr, DIR_X_PIN);
        gpioBaseAddr = (uint32_t) AddrTranslateP_getLocalAddr(EN_Y_BASE_ADDR);
        GPIO_pinWriteLow(gpioBaseAddr, EN_Y_PIN);
        gpioBaseAddr = (uint32_t) AddrTranslateP_getLocalAddr(STEP_Y_BASE_ADDR);
        GPIO_pinWriteLow(gpioBaseAddr, STEP_Y_PIN);
        gpioBaseAddr = (uint32_t) AddrTranslateP_getLocalAddr(DIR_Y_BASE_ADDR);
        GPIO_pinWriteLow(gpioBaseAddr, DIR_Y_PIN);
        gpioBaseAddr = (uint32_t) AddrTranslateP_getLocalAddr(EN_Z_BASE_ADDR);
        GPIO_pinWriteLow(gpioBaseAddr, EN_Z_PIN);
        gpioBaseAddr = (uint32_t) AddrTranslateP_getLocalAddr(STEP_Z_BASE_ADDR);
        GPIO_pinWriteLow(gpioBaseAddr, STEP_Z_PIN);
        gpioBaseAddr = (uint32_t) AddrTranslateP_getLocalAddr(DIR_Z_BASE_ADDR);
        GPIO_pinWriteLow(gpioBaseAddr, DIR_Z_PIN);
#endif
        ClockP_sleep(delaySec);

        gpioBaseAddr = (uint32_t) AddrTranslateP_getLocalAddr(FAULT_X_BASE_ADDR);
        DebugP_log("FAULT_X 0x%x\r\n", GPIO_pinRead(gpioBaseAddr, FAULT_X_PIN));
        gpioBaseAddr = (uint32_t) AddrTranslateP_getLocalAddr(FAULT_Y_BASE_ADDR);
        DebugP_log("FAULT_Y 0x%x\r\n", GPIO_pinRead(gpioBaseAddr, FAULT_Y_PIN));
        gpioBaseAddr = (uint32_t) AddrTranslateP_getLocalAddr(FAULT_Z_BASE_ADDR);
        DebugP_log("FAULT_Z 0x%x\r\n", GPIO_pinRead(gpioBaseAddr, FAULT_Z_PIN));
        gpioBaseAddr = (uint32_t) AddrTranslateP_getLocalAddr(ALERT_X_BASE_ADDR);
        DebugP_log("ALERT_X 0x%x\r\n", GPIO_pinRead(gpioBaseAddr, ALERT_X_PIN));
        gpioBaseAddr = (uint32_t) AddrTranslateP_getLocalAddr(ALERT_Y_BASE_ADDR);
        DebugP_log("ALERT_Y 0x%x\r\n", GPIO_pinRead(gpioBaseAddr, ALERT_Y_PIN));

        loopcnt--;
    }
#endif
    DebugP_log("All tests have passed!!\r\n");

    Board_driversClose();
    Drivers_close();
}
